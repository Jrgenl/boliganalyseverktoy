# Boliganalyseverktøy - Brukermanual

## Introduksjon

Boliganalyseverktøyet er et kraftig verktøy for å analysere boligannonser fra Finn.no. Det gir deg detaljert innsikt i potensielle risikoer, høydepunkter, prisanalyse og mer, basert på informasjonen i boligannonsen.

Dette verktøyet ligner på funksjonaliteten til visning.ai, men er spesielt utviklet for å fungere med finn.no boligannonser.

## Installasjon

### Forutsetninger
- Python 3.8 eller nyere
- pip (Python pakkebehandler)
- Internettforbindelse

### Installasjonstrinn

1. Last ned eller klon prosjektet til din lokale maskin
2. Åpne en terminal og naviger til prosjektmappen
3. Kjør installasjonsskriptet:
   ```
   ./install.sh
   ```
   Dette vil:
   - Sjekke om Python er installert
   - Opprette et virtuelt miljø
   - Installere alle nødvendige avhengigheter

## Bruk av applikasjonen

### Starte applikasjonen

1. Aktiver det virtuelle miljøet:
   ```
   source boliganalyse_env/bin/activate
   ```

2. Start Streamlit-applikasjonen:
   ```
   streamlit run ui/app.py
   ```

3. Åpne nettleseren din på adressen som vises i terminalen (vanligvis http://localhost:8501)

### Analysere en boligannonse

1. Finn en boligannonse på Finn.no som du ønsker å analysere
2. Kopier URL-en til annonsen (f.eks. https://www.finn.no/realestate/homes/ad.html?finnkode=123456789)
3. Lim inn URL-en i tekstfeltet i applikasjonen
4. Klikk på "Analyser bolig"-knappen
5. Vent mens systemet henter data, behandler informasjonen og utfører analysen

### Tolke resultatene

Analyseresultatene er delt inn i flere seksjoner:

#### Boliginformasjon
Viser grunnleggende informasjon om boligen, inkludert adresse, pris, areal, boligtype, byggeår og fasiliteter.

#### Risikoer
Identifiserer potensielle problemer eller bekymringer ved boligen, kategorisert etter alvorlighetsgrad:
- Høy (rød): Alvorlige problemer som krever umiddelbar oppmerksomhet
- Medium (gul): Moderate bekymringer som bør undersøkes nærmere
- Lav (grønn): Mindre problemer eller observasjoner

#### Høydepunkter
Fremhever positive aspekter ved boligen, gruppert etter kategorier som:
- Beliggenhet
- Standard
- Uteareal
- Kjøkken og bad
- Energieffektivitet
- Fasiliteter

#### Prisanalyse
Gir innsikt i boligens pris, inkludert:
- Sammenligning av prisantydning og estimert markedsverdi
- Beregning av månedlige kostnader (lån og fellesutgifter)
- Visualisering av prisdata

## Feilsøking

### Vanlige problemer

1. **Applikasjonen starter ikke**
   - Sjekk at du har aktivert det virtuelle miljøet
   - Verifiser at alle avhengigheter er installert: `pip install -r requirements.txt`

2. **Kan ikke analysere URL**
   - Sjekk at URL-en er fra Finn.no og inneholder en gyldig finnkode
   - Verifiser at du har internettforbindelse

3. **Manglende data i analysen**
   - Noen annonser kan mangle visse detaljer, som kan påvirke analyseresultatene
   - Prøv en annen annonse med mer komplett informasjon

### Kontakt

Hvis du opplever problemer eller har spørsmål, vennligst kontakt utvikleren.

## Teknisk informasjon

Boliganalyseverktøyet består av flere komponenter:

1. **Scraper**: Henter data fra Finn.no boligannonser
2. **Databehandling**: Strukturerer og normaliserer rådata
3. **Analyse**: Identifiserer risikoer, høydepunkter og utfører prisanalyse
4. **Brukergrensesnitt**: Presenterer resultatene på en brukervennlig måte

Verktøyet er utviklet i Python og bruker følgende hovedbiblioteker:
- BeautifulSoup4 for web scraping
- Pandas for databehandling
- scikit-learn for analyse
- Streamlit for brukergrensesnitt
